var teams = [
    'CFC',
    'FCF',
    'FTK',
    'OVO',
    'TOG'
]

for(var i=0;i<teams.length;i++){
    console.log(teams[i])
}